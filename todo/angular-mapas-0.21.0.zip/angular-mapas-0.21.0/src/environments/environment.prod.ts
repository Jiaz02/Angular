export const environment = {
  production: true,
  mapboxToken: 'pk.eyJ1Ijoia2xlcml0aCIsImEiOiJja2puMHhrODI1NG95MnJwOTZldjAwd2xuIn0.qSVIwYh9D-wVyzUne3euog'
};
